package com.group.test.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Shipment {
    private String orderId;
    private String shipmentId;
    private String productId;
    private Date shipmentDate;
    private Double qty;
}
