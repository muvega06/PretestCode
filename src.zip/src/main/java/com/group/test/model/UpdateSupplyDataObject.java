package com.group.test.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UpdateSupplyDataObject {
    private String productId;
    private Date timestamp;
    private Double quantity;
}
