package com.group.test.controller;


import com.group.test.model.AvailabilityReq;
import com.group.test.model.OrderDetailsReq;
import com.group.test.model.UpdateSupplyPayload;
import com.group.test.service.PretestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.text.ParseException;
import java.util.concurrent.ExecutionException;

@RestController
public class PretestController {

    @Autowired
    PretestService pretestService;

    //1st question
    @PostMapping("/getOrderDetails")
    public ResponseEntity<Object> getOrderDetails(@RequestBody OrderDetailsReq req) throws ExecutionException, InterruptedException {

        return pretestService.getOrderDetails(req);
    }
    //2nd question
    @PostMapping("/getAvailability")
    public ResponseEntity<Object> getAvailability(@RequestBody AvailabilityReq req) {

        return pretestService.getAvailability(req);
    }

    //3rd question
    @PostMapping("/updateSupply")
    public ResponseEntity<Object> updateSupply(@RequestBody UpdateSupplyPayload req) throws ParseException {

        return pretestService.updateSupply(req);
    }
}
