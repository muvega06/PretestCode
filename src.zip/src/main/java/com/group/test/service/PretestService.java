package com.group.test.service;


import com.group.test.model.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

@Service
public class PretestService {


    //1st problem
    public ResponseEntity<Object> getOrderDetails(OrderDetailsReq req) throws InterruptedException, ExecutionException {

        //intializing the thread pool size
        ExecutorService executorService = Executors.newFixedThreadPool(5);
        List<Callable<Object>> callable = new ArrayList<>();
        List<Future<Object>> resultList ;

        try {
            //adding the methods using callable
            callable.add(() -> getOrders(req.getOrderId()));
            callable.add(() -> getShipment(req.getOrderId()));

            //invoking both the methods uasing invokeAll method
            resultList = executorService.invokeAll(callable);

            //getting respective details from the order and shipment details
            Order order = (Order) resultList.get(0).get();
            Shipment shipment = (Shipment) resultList.get(1).get();

            //returning the combined response
            return ResponseEntity.ok(new OrderDetailsResponse(order, shipment));
        } catch (Exception e) {
            throw e;
        } finally {
            //finally closing the executor service
            executorService.shutdown();
        }
    }

    public Order getOrders(String orderId) {
        //method for returning the order details
        List<Order> orderList = Arrays.asList(new Order ("Order1", "Prod1", 2.0));
        Order order = orderList.stream().filter(i -> {
            if(i.getOrderId().equals(orderId)) {
                return true;
            }
            return false;
        }).findFirst().orElse(null);

        return order;

    }
    public Shipment getShipment(String orderId) throws ParseException {
        //method for returning shipment details
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
        List<Shipment> shipmentList = Arrays.asList(new Shipment ("Order1", "Ship1", "Prod1", df.parse("2021-02-19"), Double.valueOf(2.0)));
        Shipment shipment = shipmentList.stream().filter(i -> {
            if(i.getOrderId().equals(orderId)) {
                return true;
            }
            return false;
        }).findFirst().orElse(null);

        return shipment;
    }


    //2nd question
    public ResponseEntity<Object> getAvailability(AvailabilityReq req) {

        //Setting the data
        List<SupplyDTO> supplyDTOList = Arrays.asList(new SupplyDTO("Product1",Double.valueOf(10)),
                new SupplyDTO("Product2",Double.valueOf(5)));

        List<DemandDTO> demandDTOList = Arrays.asList(new DemandDTO("Product1",Double.valueOf(2)),
                new DemandDTO("Product2",Double.valueOf(5)));

        //Storing the data according to the productId's
        List<SupplyDTO> supply = supplyDTOList.stream().filter(i -> i.getProductId().equals(req.getProductId())).collect(Collectors.toList());
        List<DemandDTO> demand = demandDTOList.stream().filter(i -> i.getProductId().equals(req.getProductId())).collect(Collectors.toList());

        //getting the supply and demand quantity respectively from above list
        List<Double> supplyQuantity = supply.stream().map(i -> i.getQuantity()).toList();
        List<Double> demandQuantity = demand.stream().map(i -> i.getQuantity()).toList();

        //getting the availability;
        Double availQuantity = supplyQuantity.get(0) - demandQuantity.get(0);

        if(availQuantity > 0) {
            //if availability> 0, returning res
            return ResponseEntity.ok(new AvailabilityRes(req.getProductId(), availQuantity));
        } else {
            //as availability not > 0, returning no content response.
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
    }

    //3rd question
    public ResponseEntity<Object> updateSupply(UpdateSupplyPayload req) throws ParseException {
        //Simple date formatter to convert the string date into the specified format
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.ENGLISH);

        //harcoding the data
        List<UpdateSupplyDataObject> supplyList = Arrays.asList(new UpdateSupplyDataObject("Product1", df.parse("2021-03-16T08:53:48.616Z"),Double.valueOf(10)),
                new UpdateSupplyDataObject("Product2", df.parse("2021-03-16T08:59:48.616Z"),Double.valueOf(5)),
                new UpdateSupplyDataObject("Product3", df.parse("2021-03-16T09:10:48.616Z"),Double.valueOf(30)),
                new UpdateSupplyDataObject("Product4", df.parse("2021-03-16T09:10:48.616Z"),Double.valueOf(20)));

        UpdateSupplyPayload res = new UpdateSupplyPayload();
        UpdateSupplyDataObject updatedObject =supplyList.stream().filter(i -> {
        if(i.getProductId().equals(req.getProductId()) && req.getUpdateTimeStamp().after(i.getTimestamp())) {
            //when request timestamp > than the data timestamp and product id is same
            res.setStatus("updated");
            res.setProductId(req.getProductId());
            res.setUpdateTimeStamp(req.getUpdateTimeStamp());
            res.setQuantity(req.getQuantity()+i.getQuantity());
            return true;
        } else {
            //else out of sync if request timestamp is not greater than the data timestamp
            res.setStatus("Out Of Sync Update");
            res.setProductId(req.getProductId());
            res.setUpdateTimeStamp(req.getUpdateTimeStamp());
            return false;
        }
        }).findFirst().orElse(null);
        return ResponseEntity.ok(res);
    }

}
